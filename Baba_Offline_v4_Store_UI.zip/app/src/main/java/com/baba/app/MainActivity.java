package com.baba.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Baba Offline v4 - marketplace-style UI inspired by the supplied Baba mockup.
 * Runtime is fully offline: catalog, cart, customer details and orders live on this device.
 */
public class MainActivity extends Activity {
    static final int BLACK=Color.rgb(10,10,10), PANEL=Color.rgb(24,24,24), PANEL2=Color.rgb(31,31,31), RED=Color.rgb(238,22,31), WHITE=Color.WHITE, MUTED=Color.rgb(180,180,180), GREEN=Color.rgb(40,190,110);
    static final String PREF="baba_offline_v4";
    SharedPreferences prefs;
    LinearLayout root, content;
    TextView cartBadge;
    String selectedCategory="All";
    ArrayList<JSONObject> cart=new ArrayList<>();
    String[] categories={"Food","Groceries","Clothing","Cosmetics","Services","More"};
    String[] icons={"🍽","🛒","👕","💄","🏠","•••"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,0);
        seedProducts();
        if(!prefs.getBoolean("welcome_seen",false)) showWelcome(); else showHome();
    }

    TextView text(String s,float size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(WHITE); t.setPadding(14,10,14,10); return t; }
    TextView small(String s){ TextView t=text(s,12); t.setTextColor(MUTED); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setMinWidth(0); b.setPadding(10,0,10,0); b.setBackground(round(RED,16)); return b; }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(130,130,130)); e.setTextColor(WHITE); e.setTextSize(15); e.setSingleLine(false); e.setPadding(16,8,16,8); e.setBackground(round(PANEL2,14)); return e; }
    GradientDrawable round(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    GradientDrawable stroke(int color,int line,int strokeColor){ GradientDrawable g=round(color,18); g.setStroke(line,strokeColor); return g; }

    void page(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BLACK); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(8,8,8,2);
        if(!title.equals("Home")){ TextView back=text("‹",34); back.setGravity(Gravity.CENTER); back.setPadding(0,0,0,0); back.setOnClickListener(v->showHome()); top.addView(back,new LinearLayout.LayoutParams(48,58)); }
        TextView t=text(title,21); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); top.addView(t,new LinearLayout.LayoutParams(0,58,1));
        cartBadge=text("🛒 "+cart.size(),13); cartBadge.setGravity(Gravity.CENTER); cartBadge.setBackground(round(PANEL2,20)); cartBadge.setOnClickListener(v->showCart()); top.addView(cartBadge,new LinearLayout.LayoutParams(82,46));
        root.addView(top);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,4,12,18); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        bottomNav();
    }

    void bottomNav(){
        LinearLayout nav=new LinearLayout(this); nav.setPadding(6,6,6,8); nav.setBackgroundColor(Color.rgb(18,18,18));
        String[] n={"⌂\nHome","▦\nCategories","🛒\nCart","▤\nOrders","☻\nAdmin"};
        for(String x:n){ TextView q=text(x,12); q.setGravity(Gravity.CENTER); q.setTextColor(MUTED); q.setPadding(2,4,2,4); q.setOnClickListener(v->{ if(x.contains("Home"))showHome(); else if(x.contains("Categories"))showCategories(); else if(x.contains("Cart"))showCart(); else if(x.contains("Orders"))showOrders(); else showAdminLogin(); }); nav.addView(q,new LinearLayout.LayoutParams(0,58,1)); }
        root.addView(nav);
    }

    void showWelcome(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setPadding(24,20,24,30); r.setBackgroundColor(BLACK); setContentView(r);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.baba_logo); logo.setAdjustViewBounds(true); r.addView(logo,new LinearLayout.LayoutParams(-1,250));
        TextView h=text("Welcome to Baba",28); h.setGravity(Gravity.CENTER); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); r.addView(h);
        TextView sub=text("Everything You Need\nUnder One Roof",18); sub.setGravity(Gravity.CENTER); sub.setTextColor(WHITE); r.addView(sub);
        TextView off=text("●  OFFLINE MODE",14); off.setGravity(Gravity.CENTER); off.setTextColor(GREEN); r.addView(off);
        Space sp=new Space(this); r.addView(sp,new LinearLayout.LayoutParams(1,18));
        Button go=button("Start Shopping"); go.setOnClickListener(v->{prefs.edit().putBoolean("welcome_seen",true).apply(); showHome();}); r.addView(go,new LinearLayout.LayoutParams(-1,56));
        TextView note=small("No internet or account is required. Your orders stay on this phone."); note.setGravity(Gravity.CENTER); r.addView(note);
    }

    void showHome(){
        page("Home");
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL); ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.baba_logo); logo.setAdjustViewBounds(true); brand.addView(logo,new LinearLayout.LayoutParams(62,62));
        TextView b=text("Baba",28); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); brand.addView(b); TextView on=small("  ● Offline"); on.setTextColor(GREEN); brand.addView(on); content.addView(brand);
        EditText search=field("Search products, food, services..."); search.setSingleLine(true); content.addView(search,margin(-1,52,0,10,0));
        LinearLayout banner=new LinearLayout(this); banner.setOrientation(LinearLayout.VERTICAL); banner.setPadding(18,12,18,12); banner.setBackground(round(PANEL,20));
        TextView bt=text("Best Quality",15); bt.setTypeface(Typeface.DEFAULT,Typeface.BOLD); banner.addView(bt); TextView bp=text("BEST PRICES",25); bp.setTypeface(Typeface.DEFAULT,Typeface.BOLD); bp.setTextColor(RED); banner.addView(bp); banner.addView(small("Shop smart. Live better.\nEverything you need under one roof.")); Button shop=button("Shop Now"); shop.setOnClickListener(v->showCategories()); banner.addView(shop,new LinearLayout.LayoutParams(120,48)); content.addView(banner,margin(-1,170,0,8,0));
        content.addView(text("Categories",20));
        HorizontalScrollView hsv=new HorizontalScrollView(this); LinearLayout cats=new LinearLayout(this); cats.setPadding(0,0,0,8);
        for(int i=0;i<categories.length;i++){ final String c=categories[i]; LinearLayout card=categoryCard(icons[i],c); card.setOnClickListener(v->{selectedCategory=c;showProducts(c);}); cats.addView(card,margin(86,104,0,0,8)); }
        hsv.addView(cats); content.addView(hsv);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); TextView ft=text("Featured Products",20); ft.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.addView(ft,new LinearLayout.LayoutParams(0,55,1)); TextView all=text("View All ›",13); all.setTextColor(RED); all.setOnClickListener(v->showProducts("All")); head.addView(all); content.addView(head);
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2); JSONArray a=products(); int shown=0; for(int i=0;i<a.length()&&shown<6;i++){JSONObject p=a.optJSONObject(i);if(p==null)continue; grid.addView(productCard(p),gridParams());shown++;} content.addView(grid);
        TextView pay=text("Easy & Secure Payments\n💵 Cash on Delivery     Easypaisa / Raast: 03469404545",13); pay.setTextColor(MUTED); content.addView(pay);
        search.setOnEditorActionListener((v,action,event)->{String q=search.getText().toString().trim(); if(!q.isEmpty()) showSearch(q); return true;});
    }

    LinearLayout categoryCard(String icon,String name){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(4,4,4,4); c.setBackground(stroke(PANEL,1,Color.rgb(60,60,60))); TextView i=text(icon,28);i.setGravity(Gravity.CENTER);c.addView(i);TextView n=text(name,12);n.setGravity(Gravity.CENTER);c.addView(n);return c; }
    LinearLayout.LayoutParams margin(int w,int h,int l,int t,int r){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,0);return p; }
    GridLayout.LayoutParams gridParams(){ GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=210;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(4,4,4,4);return p; }

    LinearLayout productCard(JSONObject p){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,10,10,8);c.setBackground(round(PANEL,18));
        TextView pic=text(productIcon(p.optString("category")),38);pic.setGravity(Gravity.CENTER);c.addView(pic,new LinearLayout.LayoutParams(-1,70));
        TextView n=text(p.optString("name"),15);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(n);TextView price=text("Rs. "+money(p.optInt("price")),15);price.setTextColor(RED);price.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(price);
        Button add=button("🛒 Add");add.setTextSize(12);add.setOnClickListener(v->{cart.add(copy(p));updateBadge();Toast.makeText(this,"Added to cart",Toast.LENGTH_SHORT).show();});c.addView(add,new LinearLayout.LayoutParams(-1,44)); return c;
    }
    String productIcon(String cat){if(cat.equalsIgnoreCase("Food"))return "🍛";if(cat.equalsIgnoreCase("Groceries"))return "🥫";if(cat.equalsIgnoreCase("Clothing"))return "👕";if(cat.equalsIgnoreCase("Cosmetics"))return "🧴";if(cat.equalsIgnoreCase("Services"))return "🏠";return "📦";}
    void updateBadge(){if(cartBadge!=null)cartBadge.setText("🛒 "+cart.size());}

    void showCategories(){ page("Categories"); GridLayout g=new GridLayout(this);g.setColumnCount(2); for(int i=0;i<categories.length;i++){final String c=categories[i]; LinearLayout card=categoryCard(icons[i],c);card.setPadding(8,12,8,12);card.setOnClickListener(v->showProducts(c));GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=150;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(6,6,6,6);g.addView(card,p);}content.addView(g); }

    void showProducts(String category){ page(category.equals("All")?"All Products":category); Button filter=button("Category: "+category+"   •   Sort by price");content.addView(filter,margin(-1,48,0,4,0)); JSONArray a=products(); GridLayout g=new GridLayout(this);g.setColumnCount(2);int count=0;for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;if(!category.equals("All")&&!category.equalsIgnoreCase(p.optString("category")))continue;g.addView(productCard(p),gridParams());count++;}content.addView(g);if(count==0)content.addView(text("No products in this category yet.",18)); }
    void showSearch(String q){page("Search");GridLayout g=new GridLayout(this);g.setColumnCount(2);int count=0;JSONArray a=products();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&p.optString("name").toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))){g.addView(productCard(p),gridParams());count++;}}content.addView(text("Results for: "+q,18));content.addView(g);if(count==0)content.addView(text("No matching products.",17));}

    void showCart(){ page("My Cart"); if(cart.isEmpty()){content.addView(text("Your cart is empty.",20));Button b=button("Continue Shopping");b.setOnClickListener(v->showHome());content.addView(b);return;} int total=0; for(int i=0;i<cart.size();i++){JSONObject p=cart.get(i);total+=p.optInt("price"); LinearLayout row=new LinearLayout(this);row.setPadding(10,10,8,10);row.setGravity(Gravity.CENTER_VERTICAL);row.setBackground(round(PANEL,16));TextView info=text(productIcon(p.optString("category"))+"  "+p.optString("name")+"\nRs. "+money(p.optInt("price")),15);row.addView(info,new LinearLayout.LayoutParams(0,82,1));Button del=button("Remove");del.setTextSize(11);final int idx=i;del.setOnClickListener(v->{cart.remove(idx);showCart();});row.addView(del,new LinearLayout.LayoutParams(90,48));content.addView(row,margin(-1,92,0,5,0)); } TextView totalT=text("Total     Rs. "+money(total),22);totalT.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(totalT);Button co=button("Proceed to Checkout");co.setOnClickListener(v->showCheckout());content.addView(co,new LinearLayout.LayoutParams(-1,56));Button clear=button("Clear Cart");clear.setOnClickListener(v->{cart.clear();showCart();});content.addView(clear); }

    void showCheckout(){ page("Checkout");content.addView(text("Delivery Address",18));EditText name=field("Full name");EditText phone=field("Phone number");EditText addr=field("House / Street / Area");content.addView(name,margin(-1,55,0,4,0));content.addView(phone,margin(-1,55,0,4,0));content.addView(addr,margin(-1,85,0,4,0));content.addView(text("Payment Method",18));RadioGroup rg=new RadioGroup(this);String[] ms={"Cash on Delivery","Easypaisa — 03469404545","Raast — 03469404545"};for(String m:ms){RadioButton r=new RadioButton(this);r.setText(m);r.setTextColor(WHITE);r.setTextSize(15);rg.addView(r);}((RadioButton)rg.getChildAt(0)).setChecked(true);content.addView(rg);EditText ref=field("Transaction / Reference Number (Easypaisa/Raast)");content.addView(ref,margin(-1,55,0,5,0));Button place=button("Place Order");place.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()||phone.getText().toString().trim().isEmpty()||addr.getText().toString().trim().isEmpty()){Toast.makeText(this,"Please complete delivery details.",Toast.LENGTH_LONG).show();return;}try{JSONArray items=new JSONArray();int total=0;for(JSONObject x:cart){items.put(copy(x));total+=x.optInt("price");}JSONObject o=new JSONObject();o.put("id",String.valueOf(System.currentTimeMillis()).substring(5));o.put("date",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));o.put("customerName",name.getText().toString().trim());o.put("phone",phone.getText().toString().trim());o.put("address",addr.getText().toString().trim());o.put("paymentMethod",((RadioButton)rg.findViewById(rg.getCheckedRadioButtonId())).getText().toString());o.put("paymentReference",ref.getText().toString().trim());o.put("total",total);o.put("status","PENDING");o.put("items",items);JSONArray orders=orders();orders.put(o);saveOrders(orders);cart.clear();showOrderDetails(o);}catch(Exception e){Toast.makeText(this,"Could not save order.",Toast.LENGTH_LONG).show();}});content.addView(place,new LinearLayout.LayoutParams(-1,58));content.addView(small("Offline mode: the order is saved on this phone. Payment verification is manual.")); }

    void showOrders(){ page("My Orders");JSONArray a=orders();if(a.length()==0){content.addView(text("No orders yet.",18));return;}for(int i=a.length()-1;i>=0;i--){JSONObject o=a.optJSONObject(i);if(o==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,12,14,12);c.setBackground(round(PANEL,18));TextView h=text("#"+o.optString("id")+"   Rs. "+money(o.optInt("total")),17);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(h);c.addView(small(o.optString("date")+"   •   "+o.optString("status")));c.addView(text("Payment: "+o.optString("paymentMethod"),13));Button open=button("View Order");open.setOnClickListener(v->showOrderDetails(o));c.addView(open,new LinearLayout.LayoutParams(-1,46));content.addView(c,margin(-1,150,0,6,0));}}
    void showOrderDetails(JSONObject o){page("Order #"+o.optString("id"));content.addView(text("Order Status",18));String st=o.optString("status");String[] ss={"PENDING","CONFIRMED","PREPARING","OUT_FOR_DELIVERY","DELIVERED"};for(String x:ss){TextView step=text((x.equals(st)?"● ":"○ ")+prettyStatus(x),16);step.setTextColor(x.equals(st)?GREEN:MUTED);content.addView(step);}content.addView(text("Delivery Address",17));content.addView(small(o.optString("customerName")+"\n"+o.optString("phone")+"\n"+o.optString("address")));content.addView(text("Payment: "+o.optString("paymentMethod"),15));content.addView(text("Total: Rs. "+money(o.optInt("total")),21));}
    String prettyStatus(String s){return s.replace("OUT_FOR_DELIVERY","Out for delivery").replace("_"," ");}

    void showAdminLogin(){page("Baba Admin");content.addView(text("Manage your offline store",21));content.addView(small("Products, stock, orders and order status are stored locally."));EditText pin=field("Admin PIN");pin.setInputType(2);content.addView(pin,margin(-1,55,0,8,0));Button open=button("Open Admin Dashboard");open.setOnClickListener(v->{if(pin.getText().toString().equals(prefs.getString("admin_pin","1234")))showAdmin();else Toast.makeText(this,"Wrong PIN",Toast.LENGTH_SHORT).show();});content.addView(open);Button change=button("Change Admin PIN");change.setOnClickListener(v->changePin());content.addView(change);content.addView(small("Default PIN: 1234 — change it before regular use."));}
    void changePin(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,4,20,4);EditText old=field("Current PIN"),neu=field("New PIN");old.setInputType(2);neu.setInputType(2);l.addView(old);l.addView(neu);new AlertDialog.Builder(this).setTitle("Change Admin PIN").setView(l).setPositiveButton("Save",(d,w)->{if(old.getText().toString().equals(prefs.getString("admin_pin","1234"))&&neu.getText().toString().length()>=4){prefs.edit().putString("admin_pin",neu.getText().toString()).apply();Toast.makeText(this,"PIN changed",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Invalid PIN",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    void showAdmin(){page("Admin Dashboard");JSONArray o=orders();int pending=0,delivered=0;for(int i=0;i<o.length();i++){JSONObject x=o.optJSONObject(i);if(x==null)continue;if(x.optString("status").equals("PENDING"))pending++;if(x.optString("status").equals("DELIVERED"))delivered++;}LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.HORIZONTAL);stats.addView(statCard("Orders",String.valueOf(o.length())),new LinearLayout.LayoutParams(0,100,1));stats.addView(statCard("Pending",String.valueOf(pending)),new LinearLayout.LayoutParams(0,100,1));stats.addView(statCard("Delivered",String.valueOf(delivered)),new LinearLayout.LayoutParams(0,100,1));content.addView(stats);Button p=button("📦 Manage Products");p.setOnClickListener(v->manageProducts());content.addView(p,margin(-1,54,0,8,0));Button ord=button("🧾 Manage Orders");ord.setOnClickListener(v->showOrders());content.addView(ord,margin(-1,54,0,8,0));content.addView(small("Admin data is local to this device. There is no server sync in the offline version."));}
    LinearLayout statCard(String a,String b){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setBackground(round(PANEL,14));TextView x=text(a,12);x.setTextColor(MUTED);x.setGravity(Gravity.CENTER);c.addView(x);TextView y=text(b,24);y.setTypeface(Typeface.DEFAULT,Typeface.BOLD);y.setTextColor(RED);y.setGravity(Gravity.CENTER);c.addView(y);return c;}

    void manageProducts(){page("Manage Products");Button add=button("+ Add Product");add.setOnClickListener(v->editProductDialog(null));content.addView(add);JSONArray a=products();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,10,12,10);c.setBackground(round(PANEL,16));c.addView(text(p.optString("name")+"\nRs. "+money(p.optInt("price"))+"  •  Stock: "+p.optInt("stock"),15));LinearLayout row=new LinearLayout(this);Button e=button("Edit");e.setOnClickListener(v->editProductDialog(p));Button d=button("Delete");d.setOnClickListener(v->{deleteProduct(p.optString("id"));manageProducts();});row.addView(e,new LinearLayout.LayoutParams(0,48,1));row.addView(d,new LinearLayout.LayoutParams(0,48,1));c.addView(row);content.addView(c,margin(-1,125,0,5,0));}}
    void editProductDialog(JSONObject existing){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(18,4,18,4);EditText n=field("Product name"),cat=field("Category"),pr=field("Price"),st=field("Stock"),ds=field("Description");pr.setInputType(2);st.setInputType(2);if(existing!=null){n.setText(existing.optString("name"));cat.setText(existing.optString("category"));pr.setText(String.valueOf(existing.optInt("price")));st.setText(String.valueOf(existing.optInt("stock")));ds.setText(existing.optString("description"));}l.addView(n);l.addView(cat);l.addView(pr);l.addView(st);l.addView(ds);new AlertDialog.Builder(this).setTitle(existing==null?"Add Product":"Edit Product").setView(l).setPositiveButton("Save",(d,w)->{try{if(n.getText().toString().trim().isEmpty())return;JSONArray a=products();JSONObject p=existing==null?new JSONObject():existing;p.put("id",existing==null?String.valueOf(System.currentTimeMillis()):existing.optString("id"));p.put("name",n.getText().toString().trim());p.put("category",cat.getText().toString().trim());p.put("price",Integer.parseInt(pr.getText().toString().trim()));p.put("stock",Integer.parseInt(st.getText().toString().trim()));p.put("description",ds.getText().toString().trim());if(existing==null)a.put(p);saveProducts(a);manageProducts();}catch(Exception e){Toast.makeText(this,"Check product fields.",Toast.LENGTH_LONG).show();}}).setNegativeButton("Cancel",null).show();}

    void deleteProduct(String id){JSONArray a=products(),out=new JSONArray();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!id.equals(p.optString("id")))out.put(p);}saveProducts(out);}
    void seedProducts(){if(prefs.contains("products"))return;try{JSONArray a=new JSONArray();a.put(product("1","Chicken Biryani","Food",250,20,"Fresh chicken biryani"));a.put(product("2","Cooking Oil 1L","Groceries",550,15,"Everyday cooking oil"));a.put(product("3","Men's Shalwar Kameez","Clothing",2800,8,"Traditional clothing"));a.put(product("4","Face Wash","Cosmetics",650,10,"Daily face cleanser"));a.put(product("5","Home Delivery Service","Services",300,50,"Local delivery service"));a.put(product("6","General Item","More",500,10,"Add your own products from Admin"));saveProducts(a);}catch(Exception ignored){}}
    JSONObject product(String id,String name,String cat,int price,int stock,String desc)throws Exception{return new JSONObject().put("id",id).put("name",name).put("category",cat).put("price",price).put("stock",stock).put("description",desc);}
    JSONArray products(){try{return new JSONArray(prefs.getString("products","[]"));}catch(Exception e){return new JSONArray();}}
    void saveProducts(JSONArray a){prefs.edit().putString("products",a.toString()).apply();}
    JSONArray orders(){try{return new JSONArray(prefs.getString("orders","[]"));}catch(Exception e){return new JSONArray();}}
    void saveOrders(JSONArray a){prefs.edit().putString("orders",a.toString()).apply();}
    JSONObject copy(JSONObject x){try{return new JSONObject(x.toString());}catch(Exception e){return new JSONObject();}}
    String money(int n){return String.format(Locale.getDefault(),"%,d",n);}
}
