# Baba Offline Android App v3

This version is intentionally **offline-only**. It does not require a server, login API, Wi-Fi, or mobile data.

## Included
- Baba black/red/white branding and supplied logo
- Food, Groceries, Clothing, Cosmetics, Services and More categories
- Local product catalog with sample products
- Cart and offline checkout
- Cash on Delivery
- Easypaisa / Raast manual payment reference
- Payment number: 03469404545
- Local order history and status changes
- Offline admin dashboard
- Add/edit/delete products and stock
- Admin PIN (default 1234; change it in the app)
- No INTERNET permission

## Important
Data is stored on the device. It is not shared with other phones. Uninstalling the app or clearing its storage can remove the local data.

The app is structured so a future online/sync version can be added later.

## Build on phone with GitHub Actions
1. Upload this project to a GitHub repository.
2. Run the included `build-apk.yml` workflow.
3. Download the `Baba-Offline-APK` artifact.

The project uses Android Gradle Plugin 8.7.3 / Gradle 8.9 and compile SDK 35.
