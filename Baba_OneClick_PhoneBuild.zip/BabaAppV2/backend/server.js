const http=require('http'), fs=require('fs'), path=require('path'), crypto=require('crypto');
const PORT=process.env.PORT||8080, DB=path.join(__dirname,'data.json');
const ADMIN_PHONE=process.env.ADMIN_PHONE||'03469404545', ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'CHANGE_ME_NOW';
let db={users:[],products:[],orders:[]}; if(fs.existsSync(DB)){try{db=JSON.parse(fs.readFileSync(DB,'utf8'));}catch(e){}}
if(!db.products.length){db.products=[
{id:'p1',name:'Fresh Burger',category:'Food',price:450,description:'Freshly prepared burger.'},
{id:'p2',name:'Family Grocery Pack',category:'Groceries',price:2500,description:'Everyday household groceries.'},
{id:'p3',name:"Men's Shalwar Kameez",category:'Clothing',price:3500,description:'Traditional clothing.'},
{id:'p4',name:'Beauty Care Kit',category:'Cosmetics',price:1800,description:'Everyday beauty essentials.'},
{id:'p5',name:'Home Cleaning Service',category:'Services',price:1500,description:'Book a home cleaning service.'},
{id:'p6',name:'Everyday Essentials',category:'More',price:999,description:'Useful daily items.'}
];save();}
function save(){fs.writeFileSync(DB,JSON.stringify(db,null,2));}
function hash(p,s=crypto.randomBytes(16).toString('hex')){return s+':'+crypto.scryptSync(p,s,32).toString('hex')}
function verify(p,h){const [s,x]=String(h).split(':');try{return crypto.timingSafeEqual(Buffer.from(x,'hex'),crypto.scryptSync(p,s,32));}catch{return false}}
function token(user){const payload=Buffer.from(JSON.stringify({uid:user.id,exp:Date.now()+1000*60*60*24*30})).toString('base64url');const sig=crypto.createHmac('sha256',process.env.TOKEN_SECRET||'CHANGE_TOKEN_SECRET').update(payload).digest('base64url');return payload+'.'+sig}
function userFrom(req){const h=req.headers.authorization||'',t=h.startsWith('Bearer ')?h.slice(7):'';if(!t)return null;const [p,s]=t.split('.');try{const good=crypto.createHmac('sha256',process.env.TOKEN_SECRET||'CHANGE_TOKEN_SECRET').update(p).digest('base64url');if(s!==good)return null;const x=JSON.parse(Buffer.from(p,'base64url'));if(x.exp<Date.now())return null;return db.users.find(u=>u.id===x.uid)||null}catch{return null}}
function send(res,code,obj,headers={}){const b=JSON.stringify(obj);res.writeHead(code,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PATCH,OPTIONS',...headers});res.end(b)}
function read(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1e6)req.destroy()});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});req.on('error',reject)})}
function id(){return crypto.randomBytes(8).toString('hex')}
const server=http.createServer(async(req,res)=>{if(req.method==='OPTIONS'){send(res,204,{});return}try{
const u=new URL(req.url,'http://localhost');
if(req.method==='GET'&&u.pathname==='/api/products'){let p=db.products;if(u.searchParams.get('category'))p=p.filter(x=>x.category===u.searchParams.get('category'));send(res,200,{products:p});return}
if(req.method==='POST'&&u.pathname==='/api/auth/register'){const b=await read(req);if(db.users.some(x=>x.phone===b.phone))return send(res,409,{error:'Phone already registered'});const user={id:id(),phone:String(b.phone),passwordHash:hash(String(b.password)),role:'customer',createdAt:new Date().toISOString()};db.users.push(user);save();return send(res,201,{token:token(user),user:{id:user.id,phone:user.phone,role:user.role}})}
if(req.method==='POST'&&u.pathname==='/api/auth/login'){const b=await read(req);let user=db.users.find(x=>x.phone===String(b.phone));if(!user&&String(b.phone)===ADMIN_PHONE&&String(b.password)===ADMIN_PASSWORD){user={id:'admin',phone:ADMIN_PHONE,passwordHash:hash(ADMIN_PASSWORD),role:'admin'};db.users.push(user);save()}if(!user||!verify(String(b.password),user.passwordHash))return send(res,401,{error:'Invalid phone or password'});return send(res,200,{token:token(user),user:{id:user.id,phone:user.phone,role:user.role}})}
if(req.method==='POST'&&u.pathname==='/api/orders'){const user=userFrom(req);if(!user)return send(res,401,{error:'Login required'});const b=await read(req);if(!b.items?.length)return send(res,400,{error:'Cart is empty'});let items=[],total=0;for(const i of b.items){const p=db.products.find(x=>x.id===i.productId);if(!p)continue;const q=Math.max(1,Number(i.quantity)||1);items.push({productId:p.id,name:p.name,price:p.price,quantity:q});total+=p.price*q;}if(!items.length)return send(res,400,{error:'No valid products'});const o={id:id(),userId:user.id,customerName:String(b.customerName||''),phone:String(b.phone||''),address:String(b.address||''),paymentMethod:String(b.paymentMethod||'Cash on Delivery'),paymentReference:String(b.paymentReference||''),items,total,status:'PENDING',createdAt:new Date().toISOString()};db.orders.unshift(o);save();return send(res,201,{order:o})}
if(req.method==='GET'&&u.pathname==='/api/orders/mine'){const user=userFrom(req);if(!user)return send(res,401,{error:'Login required'});return send(res,200,{orders:db.orders.filter(o=>o.userId===user.id)})}
if(u.pathname.startsWith('/api/admin/')){const user=userFrom(req);if(!user||user.role!=='admin')return send(res,403,{error:'Admin access required'});if(req.method==='GET'&&u.pathname==='/api/admin/orders')return send(res,200,{orders:db.orders});if(req.method==='PATCH'&&u.pathname.startsWith('/api/admin/orders/')){const o=db.orders.find(x=>x.id===u.pathname.split('/').pop());if(!o)return send(res,404,{error:'Order not found'});const b=await read(req);o.status=String(b.status||o.status);save();return send(res,200,{order:o})}}
if(req.method==='GET'&&u.pathname==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(fs.readFileSync(path.join(__dirname,'public','admin.html')));return}
send(res,404,{error:'Not found'});
}catch(e){send(res,500,{error:e.message||'Server error'})}});
server.listen(PORT,()=>console.log('Baba backend listening on '+PORT));
