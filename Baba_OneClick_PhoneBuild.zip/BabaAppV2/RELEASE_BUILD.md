# Baba 2.0.0 release configuration

- App name: Baba
- Application ID: com.baba.marketplace
- Version: 2.0.0 (versionCode 200)
- Target SDK: 35
- Minimum SDK: 23
- Orientation: portrait
- Internet permission enabled
- Cleartext HTTP disabled
- Backup disabled
- Baba logo included

## Create a release APK

1. Install Android Studio with Android SDK 35.
2. Open this `BabaAppV2` folder.
3. Create a private signing key/keystore in Android Studio (Build > Generate Signed Bundle / APK), or create one with `keytool`.
4. Copy `keystore.properties.example` to `keystore.properties` and replace the placeholder values with your keystore details.
5. Build with **Build > Generate Signed Bundle / APK > APK > release**.

The output will be under `app/build/outputs/apk/release/`.

Do not share the keystore, keystore.properties, or passwords. Keep the same signing key for future Baba updates.
