# Baba — One-click APK build from an Android phone

This project is prepared for building the Baba APK in GitHub Actions. You do **not** need Android Studio or a computer.

## Phone-only steps

1. Open GitHub in Chrome on your Android phone and create/sign in to your account.
2. Create a new repository, for example `baba-app`.
3. Upload the contents of this `BabaAppV2` folder to the repository. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. Select **Build Baba APK**.
6. Tap **Run workflow**.
7. If your backend is already online, enter its HTTPS URL in `api_base`. If it is not ready yet, leave the default placeholder; the APK will still build, but online features will not work until the backend URL is configured.
8. Open the completed workflow run and download the **Baba-APK** artifact.
9. Extract the artifact and install `Baba.apk` on your Android phone.

GitHub Actions is designed to automate builds in the cloud. The workflow uses Java 17, Android SDK API 35, AGP 8.7.3 and Gradle 8.9.

## Important

- The debug APK is signed for testing and can be installed on an Android phone.
- This is a build/test APK, not the final Play Store release signing setup.
- The Baba app needs a real HTTPS backend URL to support online accounts, products and orders.
- Never put the backend admin password, JWT secret, or private payment/API credentials into the APK.
