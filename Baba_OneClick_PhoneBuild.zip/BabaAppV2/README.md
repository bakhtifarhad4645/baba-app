# Baba Online Marketplace v2

Baba is an all-in-one marketplace app for food, groceries, clothing, cosmetics, services and other items.

## What's new in v2
- Real online customer accounts (phone + password)
- Secure JWT sessions
- Central online product catalog
- Central online orders database
- Customer order history and live status refresh
- Admin login and dashboard
- Admin order status updates: Pending, Confirmed, Preparing, Out for delivery, Delivered, Cancelled
- Admin product creation
- Easypaisa payment option: **03469404545**
- Raast payment option: **03469404545**
- Cash on Delivery
- Online-payment transaction/reference number
- Your Baba black/red/white logo

## Important: connect the app to your server
Open:
`app/src/main/java/com/baba/app/MainActivity.java`

Change:
`https://YOUR-BABA-SERVER.example.com`

to your real HTTPS API address, for example `https://api.yourdomain.com`.

Do not put admin passwords, JWT secrets, or private payment/API keys in the Android app.

## Backend quick start
Requirements: Node.js 18+.

1. `cd backend`
2. Copy `.env.example` to `.env`
3. Set a long random `JWT_SECRET`
4. Set a strong `ADMIN_PASSWORD`
5. `npm install`
6. `npm start`

The API will listen on port 3000.

## Docker deployment
From the project root:

1. Copy `backend/.env.example` to `backend/.env`.
2. Set `JWT_SECRET` and `ADMIN_PASSWORD`.
3. Run `docker compose up -d --build`.
4. Put an HTTPS reverse proxy (Caddy/Nginx/Cloudflare) in front of port 3000 for production.

The database is stored in a Docker volume.

## Admin login
The first startup creates an admin using `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env`.
The admin signs in through the same Baba app login screen. The server determines whether the account is a customer or admin.

## Payment flow
The app does not pretend that a phone number is an API gateway. For Easypaisa/Raast, the customer pays using the displayed account number, enters the transaction/reference number, and the admin verifies it before fulfilling the order.

For automatic payment confirmation, an official merchant/API integration would need to be added separately using credentials supplied by the payment provider.

## Building the APK from an Android phone
See `PHONE_BUILD.md`. The included GitHub Actions workflow builds a signed debug APK in the cloud. From your phone, upload this project to GitHub, open Actions → **Build Baba APK** → **Run workflow**, optionally enter your HTTPS backend URL, and download the `Baba.apk` artifact.

For production release signing, use a private keystore and the release signing configuration; do not store private signing credentials in the repository.
