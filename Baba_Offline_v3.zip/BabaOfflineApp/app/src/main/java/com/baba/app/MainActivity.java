package com.baba.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Baba Offline v3
 * No INTERNET permission and no server dependency.
 * Products, cart, settings and orders are stored locally on the device.
 */
public class MainActivity extends Activity {
    static final int BLACK=Color.rgb(17,17,17), RED=Color.rgb(227,27,35), WHITE=Color.WHITE, GRAY=Color.rgb(190,190,190), DARK=Color.rgb(35,35,35);
    static final String PREF="baba_offline";
    SharedPreferences prefs;
    LinearLayout content, root;
    TextView title, cartBadge;
    ArrayList<JSONObject> cart=new ArrayList<>();
    String selectedCategory="All";

    String[] categories={"All","Food","Groceries","Clothing","Cosmetics","Services","More"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,0);
        seedProducts();
        showHome();
    }

    TextView tv(String s,float sz){TextView t=new TextView(this);t.setText(s);t.setTextSize(sz);t.setTextColor(WHITE);t.setPadding(16,12,16,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackgroundColor(RED);return b;}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(GRAY);e.setTextColor(WHITE);e.setPadding(16,8,16,8);return e;}

    void base(String name){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BLACK);setContentView(root);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        title=tv(name,22);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);bar.addView(title,new LinearLayout.LayoutParams(0,70,1));
        cartBadge=tv("Cart "+cart.size(),14);bar.addView(cartBadge);root.addView(bar);
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(10,5,10,15);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);String[] n={"Home","Cart","Orders","Admin"};for(String x:n){Button q=btn(x);q.setOnClickListener(v->{if(x.equals("Home"))showHome();else if(x.equals("Cart"))showCart();else if(x.equals("Orders"))showOrders();else showAdminLogin();});nav.addView(q,new LinearLayout.LayoutParams(0,62,1));}root.addView(nav);
    }

    void showHome(){
        base("BABA — OFFLINE");
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.baba_logo);logo.setAdjustViewBounds(true);content.addView(logo,new LinearLayout.LayoutParams(-1,240));
        TextView s=tv("Everything you need, from Baba.\nWorks without internet.",18);s.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(s);
        content.addView(tv("Categories",19));
        LinearLayout cats=new LinearLayout(this);cats.setOrientation(LinearLayout.VERTICAL);
        for(String c:categories){Button b=btn(c);b.setOnClickListener(v->{selectedCategory=c;showProducts(c);});cats.addView(b,new LinearLayout.LayoutParams(-1,55));}content.addView(cats);
        content.addView(tv("Payment: Cash on Delivery, Easypaisa or Raast.\nEasypaisa/Raast: 03469404545",14));
    }

    void showProducts(String category){
        base(category.equals("All")?"All Products":category);
        Button back=btn("← Back to Home");back.setOnClickListener(v->showHome());content.addView(back);
        JSONArray products=products();
        int count=0;
        for(int i=0;i<products.length();i++){
            JSONObject p=products.optJSONObject(i);if(p==null)continue;
            if(!category.equals("All")&&!category.equalsIgnoreCase(p.optString("category")))continue;
            addProduct(p);count++;
        }
        if(count==0)content.addView(tv("No products in this category yet.",18));
    }

    void addProduct(JSONObject p){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(12,12,12,12);card.setBackgroundColor(DARK);
        TextView n=tv(p.optString("name"),18);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(n);
        card.addView(tv(p.optString("category")+"  •  Rs. "+money(p.optInt("price")),14));
        if(!p.optString("description").isEmpty())card.addView(tv(p.optString("description"),13));
        card.addView(tv("Stock: "+p.optInt("stock",0),13));
        Button b=btn(p.optInt("stock",0)>0?"Add to cart":"Out of stock");b.setEnabled(p.optInt("stock",0)>0);
        b.setOnClickListener(v->{cart.add(copy(p));cartBadge.setText("Cart "+cart.size());Toast.makeText(this,"Added to cart",Toast.LENGTH_SHORT).show();});card.addView(b);content.addView(card);
    }

    void showCart(){
        base("Your Cart");
        if(cart.isEmpty()){content.addView(tv("Your cart is empty.",20));Button b=btn("Browse products");b.setOnClickListener(v->showHome());content.addView(b);return;}
        int total=0;for(JSONObject p:cart){int price=p.optInt("price");total+=price;content.addView(tv("• "+p.optString("name")+" — Rs. "+money(price),16));}
        content.addView(tv("Total: Rs. "+money(total),22));
        Button clear=btn("Clear cart");clear.setOnClickListener(v->{cart.clear();showCart();});content.addView(clear);
        Button c=btn("Checkout");c.setOnClickListener(v->showCheckout());content.addView(c);
    }

    void showCheckout(){
        base("Checkout — Offline");
        EditText name=field("Full name"),phone=field("Phone number"),addr=field("Delivery address");content.addView(name);content.addView(phone);content.addView(addr);
        content.addView(tv("Payment method",18));
        RadioGroup rg=new RadioGroup(this);String[] ms={"Cash on Delivery","Easypaisa — 03469404545","Raast — 03469404545"};
        for(String m:ms){RadioButton r=new RadioButton(this);r.setText(m);r.setTextColor(WHITE);r.setTextSize(16);rg.addView(r);}((RadioButton)rg.getChildAt(0)).setChecked(true);content.addView(rg);
        EditText ref=field("Easypaisa/Raast transaction reference (optional for COD)");content.addView(ref);
        Button p=btn("Place Order Offline");p.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()||phone.getText().toString().trim().isEmpty()||addr.getText().toString().trim().isEmpty()){Toast.makeText(this,"Complete delivery details.",Toast.LENGTH_LONG).show();return;}
            try{
                JSONArray items=new JSONArray();int total=0;for(JSONObject x:cart){items.put(copy(x));total+=x.optInt("price");}
                JSONObject o=new JSONObject();o.put("id",String.valueOf(System.currentTimeMillis()));o.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()));o.put("customerName",name.getText().toString().trim());o.put("phone",phone.getText().toString().trim());o.put("address",addr.getText().toString().trim());o.put("paymentMethod",((RadioButton)rg.findViewById(rg.getCheckedRadioButtonId())).getText().toString());o.put("paymentReference",ref.getText().toString().trim());o.put("total",total);o.put("status","PENDING");o.put("items",items);
                JSONArray orders=orders();orders.put(o);saveOrders(orders);cart.clear();Toast.makeText(this,"Order saved on this phone.",Toast.LENGTH_LONG).show();showOrders();
            }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
        });content.addView(p);
        content.addView(tv("This order is stored only on this device.\nOnline payment is manual: send payment to 03469404545 using Easypaisa or Raast and keep the reference number.",14));
    }

    void showOrders(){
        base("Orders — Offline");
        JSONArray a=orders();if(a.length()==0){content.addView(tv("No orders yet.",18));return;}
        for(int i=a.length()-1;i>=0;i--){JSONObject o=a.optJSONObject(i);if(o==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,10,10,10);c.setBackgroundColor(DARK);c.addView(tv("Order #"+o.optString("id")+"\n"+o.optString("date")+"\nRs. "+money(o.optInt("total"))+"\nPayment: "+o.optString("paymentMethod")+"\nStatus: "+o.optString("status")+"\nCustomer: "+o.optString("customerName")+"\nPhone: "+o.optString("phone")+"\nAddress: "+o.optString("address"),15));
            Button status=btn("Change status");status.setOnClickListener(v->changeOrderStatus(o));c.addView(status);content.addView(c);}
    }

    void changeOrderStatus(JSONObject o){
        final String[] ss={"PENDING","CONFIRMED","PREPARING","OUT_FOR_DELIVERY","DELIVERED","CANCELLED"};
        new AlertDialog.Builder(this).setTitle("Order status").setItems(ss,(d,which)->{try{o.put("status",ss[which]);replaceOrder(o);showOrders();}catch(Exception e){}}).show();
    }

    void showAdminLogin(){
        base("Admin");content.addView(tv("Offline Admin",20));content.addView(tv("Manage products and orders stored on this phone.",14));
        EditText pin=field("Admin PIN");pin.setInputType(2);content.addView(pin);Button b=btn("Open Admin");b.setOnClickListener(v->{if(pin.getText().toString().equals(prefs.getString("admin_pin","1234")))showAdmin();else Toast.makeText(this,"Wrong PIN",Toast.LENGTH_SHORT).show();});content.addView(b);
        Button change=btn("Change Admin PIN");change.setOnClickListener(v->changePin());content.addView(change);content.addView(tv("Default PIN for this offline build: 1234. Change it before regular use.",13));
    }

    void changePin(){
        LinearLayout l=new LinearLayout(this);l.setPadding(20,5,20,5);l.setOrientation(LinearLayout.VERTICAL);EditText old=field("Current PIN"),neu=field("New PIN");old.setInputType(2);neu.setInputType(2);l.addView(old);l.addView(neu);
        new AlertDialog.Builder(this).setTitle("Change Admin PIN").setView(l).setPositiveButton("Save",(d,w)->{if(old.getText().toString().equals(prefs.getString("admin_pin","1234"))&&neu.getText().toString().length()>=4){prefs.edit().putString("admin_pin",neu.getText().toString()).apply();Toast.makeText(this,"PIN changed",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Invalid PIN",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();
    }

    void showAdmin(){
        base("Admin Dashboard");
        content.addView(tv("Baba Offline Admin",20));
        Button add=btn("+ Add Product");add.setOnClickListener(v->addProductDialog());content.addView(add);
        Button products=btn("Manage Products");products.setOnClickListener(v->manageProducts());content.addView(products);
        Button orders=btn("Manage Orders");orders.setOnClickListener(v->showOrders());content.addView(orders);
        content.addView(tv("All data is stored locally on this device. No internet is required.",14));
    }

    void manageProducts(){
        base("Manage Products");Button add=btn("+ Add Product");add.setOnClickListener(v->addProductDialog());content.addView(add);
        JSONArray a=products();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,10,10,10);c.setBackgroundColor(DARK);c.addView(tv(p.optString("name")+"\n"+p.optString("category")+" • Rs. "+money(p.optInt("price"))+" • Stock "+p.optInt("stock"),15));LinearLayout row=new LinearLayout(this);Button edit=btn("Edit");edit.setOnClickListener(v->editProductDialog(p));Button del=btn("Delete");del.setOnClickListener(v->{deleteProduct(p.optString("id"));manageProducts();});row.addView(edit,new LinearLayout.LayoutParams(0,55,1));row.addView(del,new LinearLayout.LayoutParams(0,55,1));c.addView(row);content.addView(c);}
    }

    void addProductDialog(){editProductDialog(null);}
    void editProductDialog(JSONObject existing){
        LinearLayout l=new LinearLayout(this);l.setPadding(20,5,20,5);l.setOrientation(LinearLayout.VERTICAL);
        EditText name=field("Product name"),cat=field("Category (Food/Groceries/Clothing/Cosmetics/Services/More)"),price=field("Price"),stock=field("Stock"),desc=field("Description");price.setInputType(2);stock.setInputType(2);if(existing!=null){name.setText(existing.optString("name"));cat.setText(existing.optString("category"));price.setText(String.valueOf(existing.optInt("price")));stock.setText(String.valueOf(existing.optInt("stock")));desc.setText(existing.optString("description"));}for(EditText e:new EditText[]{name,cat,price,stock,desc})l.addView(e);
        new AlertDialog.Builder(this).setTitle(existing==null?"Add Product":"Edit Product").setView(l).setPositiveButton("Save",(d,w)->{try{if(name.getText().toString().trim().isEmpty())return;JSONArray a=products();JSONObject p=existing==null?new JSONObject():existing;p.put("id",existing==null?String.valueOf(System.currentTimeMillis()):existing.optString("id"));p.put("name",name.getText().toString().trim());p.put("category",cat.getText().toString().trim());p.put("price",Integer.parseInt(price.getText().toString().trim()));p.put("stock",Integer.parseInt(stock.getText().toString().trim()));p.put("description",desc.getText().toString().trim());if(existing==null)a.put(p);saveProducts(a);manageProducts();}catch(Exception e){Toast.makeText(this,"Check product fields.",Toast.LENGTH_LONG).show();}}).setNegativeButton("Cancel",null).show();
    }

    void deleteProduct(String id){JSONArray a=products(),out=new JSONArray();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!id.equals(p.optString("id")))out.put(p);}saveProducts(out);}
    void replaceOrder(JSONObject updated){JSONArray a=orders();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&updated.optString("id").equals(o.optString("id"))){a.remove(i);a.put(i,updated);break;}}saveOrders(a);}

    void seedProducts(){if(prefs.contains("products"))return;try{JSONArray a=new JSONArray();a.put(product("1","Biryani","Food",250,20,"Fresh chicken biryani"));a.put(product("2","Cooking Oil 1L","Groceries",550,15,"Everyday cooking oil"));a.put(product("3","Men's Shalwar Kameez","Clothing",2800,8,"Traditional clothing"));a.put(product("4","Face Wash","Cosmetics",650,10,"Daily face cleanser"));a.put(product("5","Home Delivery Service","Services",300,50,"Local delivery service"));a.put(product("6","General Item","More",500,10,"Add your own products from Admin"));saveProducts(a);}catch(Exception ignored){}}
    JSONObject product(String id,String name,String cat,int price,int stock,String desc)throws Exception{return new JSONObject().put("id",id).put("name",name).put("category",cat).put("price",price).put("stock",stock).put("description",desc);}
    JSONArray products(){try{return new JSONArray(prefs.getString("products","[]"));}catch(Exception e){return new JSONArray();}}
    void saveProducts(JSONArray a){prefs.edit().putString("products",a.toString()).apply();}
    JSONArray orders(){try{return new JSONArray(prefs.getString("orders","[]"));}catch(Exception e){return new JSONArray();}}
    void saveOrders(JSONArray a){prefs.edit().putString("orders",a.toString()).apply();}
    JSONObject copy(JSONObject x){try{return new JSONObject(x.toString());}catch(Exception e){return new JSONObject();}}
    String money(int n){return String.format(Locale.getDefault(),"%,d",n);}
}
